/* ================================================================
   SIMPLE_SQL ASSIGNMENT - MySQL 8+
   Author: Thummar Shasang Dineshbhai
   Database: shasang_thummar
   ================================================================ */

-- QUESTION 1
-- Creating 'employees' table with required constraints:
-- Primary Key, NOT NULL for emp_name, age >= 18 (CHECK), UNIQUE email, DEFAULT salary = 30000
USE shasang_thummar;

CREATE TABLE employees (
    emp_id INT PRIMARY KEY NOT NULL,     -- Unique identifier
    emp_name VARCHAR(100) NOT NULL,      -- Cannot be empty
    age INT NOT NULL CHECK (age >= 18),  -- Must be at least 18
    email VARCHAR(255) UNIQUE,           -- No duplicate emails allowed
    salary DECIMAL(10,2) DEFAULT 30000   -- Default value if not provided
);

-- Table created successfully, ready for data insertion.
---------------------------------------------------------------------------------

-- QUESTION 2
-- Demonstrating commonly used constraints:
-- PRIMARY KEY, NOT NULL, UNIQUE, CHECK, DEFAULT, and FOREIGN KEY.

-- Primary Key Example
CREATE TABLE pk_example (
    id INT PRIMARY KEY,
    name VARCHAR(50) NOT NULL
);

-- NOT NULL Example
CREATE TABLE nn_example (
    id INT PRIMARY KEY,
    email VARCHAR(100) NOT NULL
);

-- UNIQUE Example
CREATE TABLE uq_example (
    id INT PRIMARY KEY,
    username VARCHAR(50) UNIQUE
);

-- CHECK Example
CREATE TABLE chk_example (
    id INT PRIMARY KEY,
    age INT CHECK (age >= 18)
);

-- DEFAULT Example
CREATE TABLE def_example (
    id INT PRIMARY KEY,
    salary DECIMAL(10,2) DEFAULT 30000
);

-- FOREIGN KEY Example
CREATE TABLE departments (
    dept_id INT PRIMARY KEY,
    dept_name VARCHAR(100) NOT NULL
);

CREATE TABLE emp_demo (
    emp_id INT PRIMARY KEY,
    emp_name VARCHAR(100) NOT NULL,
    dept_id INT,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
);
---------------------------------------------------------------------------------

-- QUESTION 3
-- NOT NULL prevents empty values. PRIMARY KEY is always NOT NULL and UNIQUE.

CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL
);

-- Trying to insert NULL into a primary key column will fail:
-- INSERT INTO customers VALUES (NULL, 'John Doe', 'john@example.com');
-- This will result in an error since PRIMARY KEY cannot be NULL.
---------------------------------------------------------------------------------

-- QUESTION 4
-- Using ALTER TABLE to add and remove constraints on an existing table.

-- Add UNIQUE constraint
ALTER TABLE employees ADD CONSTRAINT uq_email UNIQUE (email);

-- Remove UNIQUE constraint
ALTER TABLE employees DROP INDEX uq_email;
---------------------------------------------------------------------------------

-- QUESTION 5
-- Examples of constraint violations (commented out to avoid errors during execution):

-- Duplicate email (violates UNIQUE)
-- INSERT INTO employees VALUES (1, 'Alice', 25, 'alice@example.com', 50000);
-- INSERT INTO employees VALUES (2, 'Bob', 30, 'alice@example.com', 60000);

-- NULL in NOT NULL column
-- INSERT INTO employees VALUES (3, NULL, 28, 'jane@example.com', 45000);

-- Age < 18 (violates CHECK)
-- INSERT INTO employees VALUES (4, 'Charlie', 16, 'charlie@example.com', 32000);

-- Deleting department referenced by employees (violates FOREIGN KEY)
-- DELETE FROM departments WHERE dept_id = 1;
---------------------------------------------------------------------------------

-- QUESTION 6
-- Adding constraints to an existing 'products' table.

CREATE TABLE products (
    product_id INT,
    product_name VARCHAR(50),
    price DECIMAL(10,2)
);

-- Add PRIMARY KEY
ALTER TABLE products ADD CONSTRAINT pk_product PRIMARY KEY (product_id);

-- Add DEFAULT value for price
ALTER TABLE products ALTER COLUMN price SET DEFAULT 50.00;

-- Check structure
DESC products;
---------------------------------------------------------------------------------

-- QUESTION 7
-- INNER JOIN to get student names with their class names.

CREATE TABLE classes (
    class_id INT PRIMARY KEY,
    class_name VARCHAR(50)
);

CREATE TABLE students (
    student_id INT PRIMARY KEY,
    student_name VARCHAR(50),
    class_id INT,
    FOREIGN KEY (class_id) REFERENCES classes(class_id)
);

SELECT s.student_name, c.class_name
FROM students s
JOIN classes c ON s.class_id = c.class_id;
---------------------------------------------------------------------------------

-- QUESTION 8
-- INNER JOIN + LEFT JOIN to show all orders with customers and ensure all products are listed.

SELECT o.order_id, c.customer_name, p.product_name
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
LEFT JOIN order_details od ON o.order_id = od.order_id
LEFT JOIN products p ON od.product_id = p.product_id;
---------------------------------------------------------------------------------

-- QUESTION 9
-- Calculate total sales per product using INNER JOIN and SUM().

SELECT p.product_name, SUM(s.amount) AS total_sales
FROM sales s
JOIN products p ON s.product_id = p.product_id
GROUP BY p.product_name;
---------------------------------------------------------------------------------

-- QUESTION 10
-- Fetch order_id, customer_name, and total quantity using INNER JOIN with GROUP BY.

SELECT o.order_id, c.customer_name, SUM(od.quantity) AS total_quantity
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
JOIN order_details od ON o.order_id = od.order_id
GROUP BY o.order_id, c.customer_name;
---------------------------------------------------------------------------------
